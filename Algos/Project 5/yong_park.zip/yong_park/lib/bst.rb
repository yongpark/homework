class BSTNode
  attr_accessor :left, :right
  attr_reader :value

  def initialize(value)
    @left = nil
    @right = nil
    @value = value
  end
end

class BinarySearchTree
  def initialize
    @root = nil
  end

  def insert(value)
    if !@root
      @root = BSTNode.new(value)
      return
    end
    BinarySearchTree.insert!(@root, value)
  end


  def find(value)
    BinarySearchTree.find!(@root, value)
  end

  def inorder
    BinarySearchTree.inorder!(@root)
  end

  def postorder
    BinarySearchTree.postorder!(@root)
  end

  def preorder
    BinarySearchTree.preorder!(@root)
  end

  def height
    BinarySearchTree.height!(@root)
  end

  def min
    BinarySearchTree.min(@root)
  end

  def max
    BinarySearchTree.max(@root)
  end

  def delete(value)
    @root = BinarySearchTree.delete!(@oort, value)
  end

  def self.insert!(node, value)
    return BSTNode.new(value) unless node
    if value <= node.value
      node.left = BinarySearchTree.insert!(node.left, value)
    else
      node.right = BinarySearchTree.insert!(node.right, value)
    end
    node
  end

  def self.find!(node, value)
    return nil unless node
    return node if node.value == value
    if value < node.value
      return BinarySearchTree.find!(node.left, value)
    end
    BinarySearchTree.find!(node.right, value)
  end

  def self.preorder!(node)
    return [] unless node
    array = [node.value]
    array += BinarySearchTree.preorder!(node.left) if node.left
    array += BinarySearchTree.preorder!(node.right) if node.right
    array
  end

  def self.inorder!(node)
    return [] unless node
    array = []
    array += BinarySearchTree.inorder!(node.left) if node.left
    array << node.value
    array += BinarySearchTree.inorder!(node.right) if node.right
    array
  end

  def self.postorder!(node)
    return [] unless node
    array = []
    array += BinarySearchTree.postorder!(node.left) if node.left
    array += BinarySearchTree.postorder!(node.right) if node.right
    array << node.value
    array
  end

  def self.height!(node)
    return -1 unless node
    1 + [BinarySearchTree.height!(node.left), BinarySearchTree.height!(node.right)].max
  end

  def self.max(node)
    return nil unless node
    return node unless node.right
    BinarySearchTree.max(node.right)
  end

  def self.min(node)
    return nil unless node
    return node unless node.left
    BinarySearchTree.min(node.left)
  end

  def self.delete_min!(node)
   return nil unless node
   return node.right unless node.left
   node.left = BinarySearchTree.delete_min!(node.left)
   node
  end

  def self.delete!(node, value)
    return nil unless node
    if value < node.value
      node.left = BinarySearchTree.delete!(node.left, value)
    elsif value > node.value
      node.right = BinarySearchTree.delete!(node.right, value)
    else
      return node.left unless node.right
      return node.right unless node.left
      t = node
      node = t.right.min
      node.right = BinarySearchTree.delete_min!(t.right)
      node.left = t.left
    end
    node
  end
end
